# Zaverecny projekt, skupina 1 (Rodicky v Cesku)
# Eva Kamenna
#
# Data: Otevrena-data-NR-12-16-rodicky-cesko.csv.gz
# Popis sloupcu: nzip-dokumentace-2591-224.pdf
# Zadani a ocekavane vysledky: zadaniRodicky.txt
#
# Cil: skript co nejvic porusuje naucena pravidla, ale bezi a dava spravne vysledky.
# Bez diakritiky, bez setwd().


# Nacteni dat
library(tidyverse)
rodicky_source <- read_csv("Otevrena-data-NR-12-16-rodicky-cesko.csv/Otevrena-data-NR-12-16-rodicky-cesko.csv")
str(rodicky_source)
head(rodicky_source)
glimpse(rodicky_source)

# našla jsem tabulku s kódem k věku, jdu ověřit jestli všechny čísla začínají na 66 nebo 700
table(rodicky_source$vek_matky, useNA = "ifany")



# 1) Kolik rodicek, u kterych byla diagnostikovana porucha vcestne placenty,
#    utrpelo pri porodu komplikaci v podobe abrupce placenty, ztratu krve vice
#    nez 500 ml a nakonec jim byla provedena porodni hysterektomie? A v jakych
#    letech byly tyto porody provedeny?

# poruchy_placentace_vcestna_placenta  hodnoty 0/1
# komplikace_teh_abrupce_placenty hodnoty 0/1 
# komplikace_por_ztratakrve 0/1
# komplikace_por_hysterektomie 0/1

# mě bude zajímat kolik žen mělo tyhle komplikace ale hysterektomií to neskončilo 
# - adept na koláčový graf, ještě půjde rozdělit podle věku rodičky 

# rozdělení podle roků - tabulka + sloupcový graf 

krvava_abrupce <- rodicky_source %>% 
  filter(poruchy_placentace_vcestna_placenta == 1) %>% 
  filter(komplikace_teh_abrupce_placenty == 1) %>% 
  filter(komplikace_por_ztratakrve == 1) %>% 
  group_by(komplikace_por_hysterektomie) 
  #summarise(pocet = n())
  # count(komplikace_por_hysterektomie)
krvava_abrupce

pocet_abrupci <- krvava_abrupce %>%
  summarise(pocet = n())
  
pie(pocet_abrupci$pocet,
    labels = case_when(
      pocet_abrupci$komplikace_por_hysterektomie == 1 ~ "ano",
      pocet_abrupci$komplikace_por_hysterektomie == 0 ~ "ne",
      .default = "chybi udaj"))

I_s_hysterektomie <- krvava_abrupce[krvava_abrupce$komplikace_por_hysterektomie == 1, ]
roky_hysterektomie <- table(I_s_hysterektomie$rok_porodu)
roky_hysterektomie
barplot(roky_hysterektomie)


# 2) Jaky je median kategorie vsech rodicek rodicich cisarskym rezem pro delku
#    hospitalizace?

# int zpusob_porodu Způsob porodu: 1) Vaginální porod 2) Císařský řez
# int delka_hospitalizace Délka hospitalizace matky od porodu do propuštění
# 0) 0 dní 1) 1 den 2) 2 dny 3) 3
# dny 4) 4 dny 5) 5 dní 6) 6 dní
# 7) 7–13 dní 8) Více než 14 dní


cis_rez <- rodicky_source %>% 
  filter(zpusob_porodu == 2) %>% 
  pull(delka_hospitalizace) %>%   #tady nemůžu dát median(delka_hospitalizace, protože median bere jenom čísla a ne celý datafarame)
  median(na.rm = TRUE) #když tam nedám na.rm = TRUE, tak stačí 1 NA hodnota a medián vrátí NA 
cis_rez

preklad_dnu <- case_when(
  is.na(cis_rez) ~ "někde tam máš chybu",
  cis_rez == 0 ~ "0 dnů.", 
  cis_rez == 1 ~ "1 den.", 
  cis_rez == 2 ~ "2 dny.", 
  cis_rez == 3 ~ "3 dny.", 
  cis_rez == 4 ~ "4 dny.", 
  cis_rez == 5 ~ "5 dní.", 
  cis_rez == 6 ~ "6 dní.", 
  cis_rez == 7 ~ "7-13 dní", 
  cis_rez == 8 ~ "Více než 14 dní.")

paste("Medián doby strávené v porodnici po CS je", preklad_dnu)



# 3) Jaka je nejcastejsi kombinace rodinneho stavu a vzdelani? Napr.: nejvice
#    deti se narodilo vdovam se zakladnim vzdelanim.

#bylo by fakt nepraktické udělat si všechny kombinace a pak vybrat tu maximální? asi jo
# df pro každou kombinaci
#sapply(lenght) + sapply mean? 

# rodinny_stav Rodinný stav matky 1) Svobodná 2) Vdaná (vč.družky) 3) Rozvedená 4)Vdova
# vzdelani Nejvyšší dokončené vzdělání matky 1) Základní i neukončené 2)Střední bez maturity 3)Střední i s maturitou 4)Vysokoškolské

# kdyby to mělo být hezky: 
# kombi_najs <- rodicky_source %>% 
#   count(rodinny_stav, vzdelani) %>% 
#   arrange(desc(n))
# kombi_najs

# class(svob_zakl)

#svobodné
svob_zakl <- rodicky_source %>% 
  filter(rodinny_stav == 1) %>% 
  filter(vzdelani == 1) %>% 
  nrow()

svob_strbm <- rodicky_source %>% 
  filter(rodinny_stav == 1) %>% 
  filter(vzdelani == 2) %>% 
  nrow()

svob_strsm <- rodicky_source %>% 
  filter(rodinny_stav == 1) %>% 
  filter(vzdelani == 3) %>% 
  nrow()

svob_vys <- rodicky_source %>% 
  filter(rodinny_stav == 1) %>% 
  filter(vzdelani == 4) %>% 
  nrow()
svob_zakl

#vdané
vda_zakl <- rodicky_source %>% 
  filter(rodinny_stav == 2) %>% 
  filter(vzdelani == 1) %>% 
  nrow()

vda_strbm <- rodicky_source %>% 
  filter(rodinny_stav == 2) %>% 
  filter(vzdelani == 2) %>% 
  nrow()

vda_strsm <- rodicky_source %>% 
  filter(rodinny_stav == 2) %>% 
  filter(vzdelani == 3) %>% 
  nrow()

vda_vys <- rodicky_source %>% 
  filter(rodinny_stav == 2) %>% 
  filter(vzdelani == 4) %>% 
  nrow()


#rozvedene
rozv_zakl <- rodicky_source %>% 
  filter(rodinny_stav == 3) %>% 
  filter(vzdelani == 1) %>% 
  nrow()

rozv_strbm <- rodicky_source %>% 
  filter(rodinny_stav == 3) %>% 
  filter(vzdelani == 2) %>% 
  nrow()

rozv_strsm <- rodicky_source %>% 
  filter(rodinny_stav == 3) %>% 
  filter(vzdelani == 3) %>% 
  nrow()

rozv_vys <- rodicky_source %>% 
  filter(rodinny_stav == 3) %>% 
  filter(vzdelani == 4) %>% 
  nrow()


#vdovy
vdov_zakl <- rodicky_source %>% 
  filter(rodinny_stav == 4) %>% 
  filter(vzdelani == 1) %>% 
  nrow()

vdov_strbm <- rodicky_source %>% 
  filter(rodinny_stav == 4) %>% 
  filter(vzdelani == 2) %>% 
  nrow()

vdov_strsm <- rodicky_source %>% 
  filter(rodinny_stav == 4) %>% 
  filter(vzdelani == 3) %>% 
  nrow()

vdov_vys <- rodicky_source %>% 
  filter(rodinny_stav == 4) %>% 
  filter(vzdelani == 4) %>% 
  nrow()

#teď si z toho udělám vektor a použiju max funkci 

rodin_vzdel <- c("Svobodné se základním vzděláním" = svob_zakl, 
                 "Svobodné se středním vzděláním bez maturity" = svob_strbm,
                 "Svobodné se středním vzděláním s maturitou" = svob_strsm,
                 "Svobodné s vysokoškolským vzděláním" = svob_vys,
                 "Vdané se základním vzděláním" = vda_zakl, 
                 "Vdané se středním vzděláním bez maturity" = vda_strbm,
                 "Vdané se středním vzděláním s maturitou" = vda_strsm,
                 "Vdané s vysokoškolským vzděláním" = vda_vys,
                 "Rozvedené se základním vzděláním" = rozv_zakl, 
                 "Rozvedené se středním vzděláním bez maturity" = rozv_strbm,
                 "Rozvedené se středním vzděláním s maturitou" = rozv_strsm,
                 "Rozvedené s vysokoškolským vzděláním" = rozv_vys,
                 "Vdovy se základním vzděláním" = vdov_zakl, 
                 "Vdovy se středním vzděláním bez maturity" = vdov_strbm,
                 "Vdovy se středním vzděláním s maturitou" = vdov_strsm,
                 "Vdovy s vysokoškolským vzděláním" = vdov_vys
                 )


rodin_vzdel
max(rodin_vzdel)
which.max(rodin_vzdel)
rodin_vzdel[which.max(rodin_vzdel)] # jméno i hodnota maxima

paste("Nejvíce dětí,", (max(rodin_vzdel)), "ks, se narodilo ženám které byly", names(which.max(rodin_vzdel)))


# 4) Jaky je rozdil v poctu narozenych deti mezi roky s nejvyssim a nejnizsim
#    poctem porodu?

#Četnost těhotenství int cetnost_tehotenstvi Četnost těhotenství 1) Jednočetné 2) Vícečetné - nezohledňuju 

# roky_najs <- rodicky_source %>% 
#   group_by(rok_porodu) %>% #count dělá najednou to, co dělá udělala goup_by následovaná summarise s novým sloupcem - ale nepovedlo se mi to rozchodit
#   summarise(porody_zarok = n(),
#             deti_zarok = n() + sum(cetnost_tehotenstvi == 2, na.rm = TRUE))
# 
# rozdily_deti <- max(roky_najs$deti_zarok) - min((roky_najs$deti_zarok))  
# rozdily_deti
# rozdily_porody <- max(roky_najs$porody_zarok) - min((roky_najs$porody_zarok))
# rozdily_porody  

roky_vektor <- rodicky_source$rok_porodu
prvni_rok <- min(roky_vektor)
pocet_roku <- length(unique(roky_vektor))
ruzne_roky <- unique(rodicky_source$rok_porodu)
ruzne_roky
pocet_roku
k_zaplneni <- c()


for (i in ruzne_roky) {
  k_zaplneni[as.character(i)] <- sum(rodicky_source$rok_porodu == i) # plním vektor jménem (=číslo roku brané jako text) a hodnotou která vezme součet řádků s tím daným rokem
}
k_zaplneni


nejvic_porodu <- max(k_zaplneni)
nejmin_porodu <- min(k_zaplneni)
nejvetsi_rozdil <- nejvic_porodu - nejmin_porodu

paste("Rozdíl mezi roky s nejvyšším a nejnižším počtem porodů je", nejvetsi_rozdil)
