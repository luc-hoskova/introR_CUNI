rozpocet / (plat*pocetMesicu)
