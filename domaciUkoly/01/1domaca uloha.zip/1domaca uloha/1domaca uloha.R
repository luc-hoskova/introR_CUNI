getwd()
load("promenne.RData")

rozpocet / (plat * pocetMesicu)
