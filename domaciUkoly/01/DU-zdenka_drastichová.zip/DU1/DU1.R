rozpocet/pocetMesicu
91580 %/% plat
# Z rozpoctu lze platit po dobu 6 mesicu 3 zamestnance.