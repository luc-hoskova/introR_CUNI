load("promenne.RData")

pocetZamestnancu <- rozpocet%/%plat%/%pocetMesicu
veta <- "Mohu najmout"
veta2 <- "zaměstnance/zaměstnanců"
cat(veta,pocetZamestnancu,veta2)