plat<-30000; pocetMesicu<-6; rozpocet<-549480
"zamestnanci"<-rozpocet%/%(plat*pocetMesicu)