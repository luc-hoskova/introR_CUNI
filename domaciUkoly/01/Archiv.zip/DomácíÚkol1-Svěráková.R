plat*pocetMesicu
rozpocet%/%180000
