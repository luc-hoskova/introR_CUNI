x<-seq(15.2, 45.7, 0.56)
y<-x[seq(5, length(x),5)]


data(airquality)
airquality[airquality$Month==5 & airquality$Day<=7, "Temp"]

airquality$Weather<-airquality$Temp
airquality$Weather[airquality$Weather>70]<-"HOT"
airquality$Weather[airquality$Weather<=70]<-"COLD"

